package com.airline.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.airline.entity.TicketBooking;
import com.airline.model.TicketBookingDTO;
import com.airline.service.TicketService;
import com.airline.serviceImpl.TicketServiceImpl;
import com.airline.util.TicketConverter;

@RestController
@RequestMapping("/api")
public class TicketBookingController {
@Autowired
TicketService ticketBookingService;
@Autowired
TicketConverter ticketConverter;
@PostMapping("/bookFlight/{fid}/{pid}")
public String bookFlight(@PathVariable("fid") int fId,@PathVariable ("pid") int pId,@RequestBody TicketBookingDTO ticketBookingDTO)
{
	final TicketBooking booking=ticketConverter.convertToTicketEntity(ticketBookingDTO);
	//return new ResponseEntity<TicketBookingDTO>(ticketBookingService.bookFlight(fId,pId,booking),HttpStatus.CREATED);
return ticketBookingService.bookFlight(fId, pId, booking);	
}
//cancel booking using id
		@DeleteMapping("/cancelBooking/{id}")
		public String cancelBooking(@PathVariable("id") int id)
		{
			return ticketBookingService.cancelBooking(id);
		}
		//getting ticket details using distinct keyword as the id is unique
		@GetMapping("/getDistinctByTicketId/{id}")
		public TicketBookingDTO getDistinctByTicketId(@PathVariable("id") int id)
		{
			return ticketBookingService.getDistinctByTicketId(id);
		}	
}
