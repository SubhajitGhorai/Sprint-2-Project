package com.airline.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Builder

@Table(name = "register_admin")
public class Admin extends User{
    @Column(name = "name",length = 50)
	private String adminName;
    @Column(length = 100)
	private String email;
	/**
	 * @param id
	 * @param userName
	 * @param password
	 * @param role
	 * @param adminName
	 * @param email
	 */
    @Builder
	public Admin(int id, String userName, String password, String role, String adminName, String email) {
		super(id, userName, password, role);
		this.adminName = adminName;
		this.email = email;
	}

	}
    
