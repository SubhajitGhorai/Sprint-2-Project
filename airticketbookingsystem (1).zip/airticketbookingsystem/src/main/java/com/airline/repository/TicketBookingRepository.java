package com.airline.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.airline.entity.TicketBooking;

public interface TicketBookingRepository extends JpaRepository<TicketBooking, Integer>{
	//getting the details of a ticket using query+finder method by using the
		//keyword distinct as the id is randomly created and unique
		TicketBooking getDistinctByTicketId(int id);
}
