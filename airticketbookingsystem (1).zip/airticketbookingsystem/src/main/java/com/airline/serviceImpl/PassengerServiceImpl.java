package com.airline.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.airline.entity.Passenger;
import com.airline.exception.ResourceNotFoundException;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.service.PassengerService;
import com.airline.util.Converter;


@Service
public class PassengerServiceImpl implements PassengerService{
//Logger statically created
	private static final Logger l=LoggerFactory.getLogger(PassengerService.class);
	@Autowired
	private PassengerRepository passengerRepository;
	@Autowired
	private Converter converter;
	//method used to create or save passenger details

	@Override
	public String createPassenger(Passenger passenger) {
		String message=null;
		passenger.setUserName(passenger.getUserName());
		passenger.setPassword(passenger.getPassword());
		passenger.setRole(passenger.getRole());
		
		passengerRepository.save(passenger);
		l.info("passenger"+passenger.toString() +" added at " + new java.util.Date());
		if(passenger!=null)
		{
			message="Passenger saved Successfully!!";
		}
		return message;
	}
	//method used to update passenger details 
	@Override
	public PassengerDTO updatePassenger(int id, Passenger passenger) {
		//we need to check wheather passenger with given exist in DB or not
		Passenger existingPass=passengerRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Passenger", "id", id));
		//we will get data from client and set in existing passenger
		existingPass.setName(passenger.getName());
		existingPass.setPhno(passenger.getPhno());
		existingPass.setEmail(passenger.getEmail());
		existingPass.setUserName(passenger.getUserName());
		existingPass.setPassword(passenger.getPassword());
		existingPass.setRole(passenger.getRole());
	passengerRepository.save(existingPass);
	l.info("passenger with "+id +" is updated at " + new java.util.Date());
	return converter.convertToPassengerDTO(existingPass);
		
		
	}
	//method used to get passenger details by using the id
	@Override
	public PassengerDTO getPassengerById(int id) {
		Passenger Pass=passengerRepository.findById(id).orElseThrow(()->
		new ResourceNotFoundException("Passenger", "id", id));
		l.info("passenger with "+id +" is fetched at " + new java.util.Date());
		return converter.convertToPassengerDTO(Pass);
		
	}
	//method used to get all passenger details
	@Override
	public List<PassengerDTO> getAllPassenger() {
	List<Passenger>	 passengers=passengerRepository.findAll();
	List<PassengerDTO> passengersDTO=new ArrayList<>();
	for(Passenger pass: passengers)
	{
		passengersDTO.add(converter.convertToPassengerDTO(pass));
	}
	l.info("Fetching all passengers at " + new java.util.Date());
		return passengersDTO;
	}
	//method used to delete a passenger details using the id 
	@Override
	public String deletePassengerById(int id) {
	String msg=null;
	Optional<Passenger> opPass=passengerRepository.findById(id);
	if(opPass.isPresent())
	{
		passengerRepository.deleteById(id);
		msg="record deleted successfully";
	}
	else {
		throw new ResourceNotFoundException("Passenger", "id", id);
	}
	l.info("Passenger with "+id +" delete at"+ new java.util.Date());
	return msg;
		
	}
	//query method used to get passenger details using the name
	@Override
	public List<PassengerDTO> getPassengerByName(String name) {
		List<Passenger> passengers=(List<Passenger>) passengerRepository.getPassengerByName(name);
		List<PassengerDTO> pDto=new ArrayList<>();
		for(Passenger p: passengers)
		{
			pDto.add(converter.convertToPassengerDTO(p));
		}
		l.info("passenger"+passengers.toString() +" added at " + new java.util.Date());
		return pDto;
	}
	//query method used to get passenger details using the email
	@Override
	public PassengerDTO getPassengerByEmail(String email) {
		Passenger pass=passengerRepository.getPassengerByEmail(email);
		l.info("passenger"+pass.toString() +" added at " + new java.util.Date());
		return converter.convertToPassengerDTO(pass);
		
	}


}
