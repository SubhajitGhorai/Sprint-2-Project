package com.airline.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.airline.entity.Airline;
import com.airline.entity.Flight;
import com.airline.model.AirlineDTO;
import com.airline.model.FlightDTO;
@Component
public class AirlineConverter {
	//convert from airlineDTO to Entity(Airline)
		public Airline convertToAirlineEntity(AirlineDTO airlineDTO)
		{
			Airline airline=new Airline();
			if(airlineDTO!=null)
			{
				BeanUtils.copyProperties(airlineDTO, airline);
			}
			return airline;
		}
		
		
		//convert from airline Entity to airlineDTO
		public AirlineDTO convertToAirlineDTO(Airline airline)
		{
			AirlineDTO airlineDTO=new AirlineDTO();
			if(airline!=null)
			{
				BeanUtils.copyProperties(airline, airlineDTO);
			}
			return airlineDTO;
		}


}
