package com.airline.repository;

import static org.assertj.core.api.Assertions.assertThat;

import java.util.List;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import com.airline.entity.Admin;


@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class AdminRepositoryTest {

	@Autowired
	AdminRepository adminRepository;
	
	@Test
	@Order(1)
	void saveAdminTest()
	{
		Admin admin = Admin.builder().adminName("chayan").email("chayan@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		
		Admin a = adminRepository.save(admin);
		assertThat(a.getAdminName()).isEqualTo("chayan");
	}
	
	@Test
	@Order(3)
	void getAllAdminsTest()
	{
		List<Admin> list = adminRepository.findAll();
		assertThat(list.size()).isGreaterThan(0);
	}
	
	@Test
	@Order(2)
	@DisplayName("Negative Test Case")
	void updateAdminTest()
	{
		Admin admin = Admin.builder().adminName("chayan").email("chayan@gmail.com").
				userName("admin").password("admin123").role("admin").build();
		admin.setAdminName("pallab");
		Admin ad = adminRepository.save(admin);
		assertThat(ad.getAdminName()).isEqualTo("chayan");
	}
}
