package com.airline.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mockitoSession;
import static org.mockito.Mockito.verify;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.airline.entity.Passenger;
import com.airline.model.PassengerDTO;
import com.airline.repository.PassengerRepository;
import com.airline.util.Converter;
@SpringBootTest
public class PassengerServiceTest {
	@Autowired
	private PassengerService passengerService;
	@Autowired
	private Converter converter;
	
	@MockBean
	private PassengerRepository passengerRepository;
	
	//this method will test savePassenger Method
//	@Test
//	 void TestCreatePassenger()
//	{
//		Passenger passenger=Passenger.builder().name("chayan").email("chayan@gmail.com").phno("9134735380").userName("chayanjana1").password("180219").role("user").build();
//		
//		Mockito.when(passengerRepository.save(passenger)).thenReturn(passenger);
//		assertThat(passengerService.createPassenger(passenger)).isEqualTo("Passenger saved Successfully!!");
//		
//	}
	//this method will test getAllPassenger Method
//	@Test
//	void testGetAllPassenger()
//	{
//		Passenger passenger1 = Passenger.builder().name("chayan").email("chayan@gmail.com").
//				phno("9134735380").userName("chyanajana1").password("180219").role("user").build();
//		Passenger passenger2 = Passenger.builder().name("chandan").email("cha@gmail.com").
//				phno("9731209456").userName("chandan").password("c123").role("user").build();
//		
//		List<Passenger> list = new ArrayList<>();
//		list.add(passenger1);
//		list.add(passenger2);
//		
//		Mockito.when(passengerRepository.findAll()).thenReturn(list);
//		
//		List<PassengerDTO> dto = passengerService.getAllPassenger();
//		
//		List<Passenger> pass= new ArrayList<Passenger>();
//		dto.forEach(passDto->
//		{
//			pass.add(converter.covertToPassengerEntity(passDto));
//		});
//		
//		assertThat(pass).isEqualTo(list);
//	}
	//this method will test deletePassengerById Method
//	@Test
//	void testDeletePassenger()
//	{
//		Passenger passenger2 = Passenger.builder().name("chandan").email("cha@gmail.com").
//				phno("9731209456").userName("chandan").password("c123").role("user").build();
//	
//		Optional<Passenger> opPass=Optional.of(passenger2);
//		Mockito.when(passengerRepository.findById(opPass.get().getId())).thenReturn(opPass);
//		assertThat(passengerService.deletePassengerById(opPass.get().getId())).isEqualTo("record deleted successfully");
//	}
//	@Test
//	@DisplayName("Negetive test case")
//	void testNegetiveGetPassengerById()
//	{
//		Passenger passenger1 = Passenger.builder().name("chayan").email("chayan@gmail.com").
//				phno("9134735380").userName("chayan").password("180219").role("user").build();
//		
//		Optional<Passenger>opPass=Optional.of(passenger1);
//		Mockito.when(passengerRepository.findById(passenger1.getId())).thenReturn(opPass);
//		
//		PassengerDTO pDto=converter.convertToPassengerDTO(opPass.get());
//		assertThat(passengerService.getPassengerById(opPass.get().getId())).isEqualTo(pDto);
//	
//	}
//	@Test
//	void testUpdatePassenger()
//	{
//		Passenger passenger=Passenger.builder().name("chayan").email("chayan@gmail.com").
//				phno("9134735380").userName("chayanjana1").password("180219").role("user").build();
//		Optional<Passenger>opPass=Optional.of(passenger);
//		Mockito.when(passengerRepository.findById(passenger.getId())).thenReturn(opPass);
//		Passenger p=opPass.get();
//		p.setName("chandan");
//		Mockito.when(passengerRepository.save(p)).thenReturn(p);
//		PassengerDTO pDtp=converter.convertToPassengerDTO(p);
//	PassengerDTO dto=passengerService.updatePassenger(passenger.getId(), passenger);
//	assertEquals(dto.getName(),p.getName());
//	}
	
}
